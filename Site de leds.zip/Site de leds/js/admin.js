// Importa o Supabase
import { supabase } from './supabase.js';

// Elementos principais
const list = document.getElementById('products-list');   // Container onde os produtos aparecem
const panel = document.getElementById('edit-panel');      // Painel lateral de edição
const overlay = document.getElementById('overlay');       // Fundo escuro atrás do painel
const closeBtn = document.getElementById('close-panel');  // Botão para fechar o painel

// Campos do formulário
const nameInput = document.getElementById('edit-name');
const descInput = document.getElementById('edit-description');
const priceInput = document.getElementById('edit-price');
const categoryInput = document.getElementById('edit-category');
const imagesInput = document.getElementById('edit-images'); // **ID corrigido**

let currentProductId = null; // Guarda o ID do produto que está sendo editado

/* =========================
   BUSCA PRODUTOS DO SUPABASE
========================= */
async function loadProducts() {

  // Pega todos os produtos da tabela
  const { data, error } = await supabase
    .from('products')
    .select('*');

  if (error) {
    alert('Erro ao carregar produtos');
    console.error(error);
    return;
  }

  list.innerHTML = ''; // Limpa o container antes de renderizar

  // Renderiza cada produto como card clicável
  data.forEach(product => {
    const div = document.createElement('div');
    div.className = 'product-card';

    div.innerHTML = `
      <img src="${product.images?.[0] || ''}" alt="${product.name}">
      <h3>${product.name}</h3>
    `;

    // Ao clicar, abre painel com os dados do produto
    div.onclick = () => openPanel(product);
    list.appendChild(div);
  });
}

/* =========================
   ABRE PAINEL DE EDIÇÃO
========================= */
function openPanel(product) {
  currentProductId = product.id; // Salva o produto que está editando

  // Preenche os campos do formulário com os dados atuais do produto
  nameInput.value = product.name;
  descInput.value = product.description || '';
  priceInput.value = product.price || '';
  categoryInput.value = product.category || '';
  
  // Se houver imagens, pega a primeira para o input
  imagesInput.value = product.images?.[0] || '';

  // Mostra painel e overlay
  panel.classList.remove('hidden');
  overlay.classList.remove('hidden');
}

/* =========================
   FECHAR PAINEL
========================= */
closeBtn.onclick = () => {
  panel.classList.add('hidden');
  overlay.classList.add('hidden');
};

/* =========================
   SALVAR ALTERAÇÕES
========================= */
document.getElementById('edit-form').addEventListener('submit', async (e) => {
  e.preventDefault(); // Evita reload da página

  // Atualiza produto no Supabase
  const { error } = await supabase
    .from('products')
    .update({
      name: nameInput.value,
      description: descInput.value,
      price: Number(priceInput.value),
      category: categoryInput.value,
      images: [imagesInput.value] // sempre um array
    })
    .eq('id', currentProductId);

  if (error) {
    alert('Erro ao salvar');
    console.error(error);
    return;
  }

  alert('Produto atualizado!');
  panel.classList.add('hidden');
  overlay.classList.add('hidden');

  // Recarrega os produtos atualizados
  loadProducts();
});

// Carrega os produtos assim que a página abrir
loadProducts();